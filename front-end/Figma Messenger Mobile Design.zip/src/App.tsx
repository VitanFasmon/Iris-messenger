import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { Dashboard } from './components/Dashboard';

export interface User {
  id: string;
  username: string;
  email: string;
  avatar: string;
  status: 'online' | 'offline' | 'away';
}

export interface Message {
  id: string;
  text: string;
  senderId: string;
  timestamp: Date;
  status?: 'sent' | 'delivered' | 'read';
  attachment?: {
    type: 'image' | 'video' | 'audio' | 'file';
    url: string;
    name: string;
  };
  deleteTimer?: number; // in seconds
}

export interface Conversation {
  id: string;
  friendId: string;
  messages: Message[];
  unreadCount: number;
}

export interface Friend {
  id: string;
  username: string;
  email: string;
  avatar: string;
  status: 'online' | 'offline' | 'away';
  lastSeen?: Date;
}

export interface FriendRequest {
  id: string;
  fromUserId: string;
  toUserId: string;
  fromUser: {
    username: string;
    avatar: string;
  };
  status: 'pending' | 'accepted' | 'declined';
  timestamp: Date;
}

export type Screen = 'login' | 'register' | 'dashboard';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const handleLogin = (username: string, password: string) => {
    // Mock login
    const user: User = {
      id: 'me',
      username,
      email: `${username}@example.com`,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
      status: 'online'
    };
    setCurrentUser(user);
    setCurrentScreen('dashboard');
  };

  const handleRegister = (username: string, email: string, password: string) => {
    // Mock register
    const user: User = {
      id: 'me',
      username,
      email,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
      status: 'online'
    };
    setCurrentUser(user);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentScreen('login');
  };

  return (
    <div className="h-screen bg-gray-50 flex items-center justify-center">
      <div className="w-full max-w-md h-full bg-white shadow-xl">
        {currentScreen === 'login' && (
          <LoginScreen
            onLogin={handleLogin}
            onSwitchToRegister={() => setCurrentScreen('register')}
          />
        )}
        {currentScreen === 'register' && (
          <LoginScreen
            isRegister
            onRegister={handleRegister}
            onSwitchToLogin={() => setCurrentScreen('login')}
          />
        )}
        {currentScreen === 'dashboard' && currentUser && (
          <Dashboard
            currentUser={currentUser}
            onLogout={handleLogout}
          />
        )}
      </div>
    </div>
  );
}
