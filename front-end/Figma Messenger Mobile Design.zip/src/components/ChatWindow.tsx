import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, MoreVertical, Send, Image as ImageIcon, Paperclip, Smile, Timer, UserMinus } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Friend, Conversation, Message } from '../App';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface ChatWindowProps {
  friend: Friend;
  conversation: Conversation | null;
  onBack: () => void;
  onSendMessage: (text: string, deleteTimer?: number, attachment?: Message['attachment']) => void;
  onRemoveFriend?: (friendId: string) => void;
}

export function ChatWindow({ friend, conversation, onBack, onSendMessage, onRemoveFriend }: ChatWindowProps) {
  const [messageText, setMessageText] = useState('');
  const [deleteTimer, setDeleteTimer] = useState<number | undefined>(undefined);
  const [showRemoveDialog, setShowRemoveDialog] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages]);

  const handleSend = () => {
    if (messageText.trim()) {
      onSendMessage(messageText, deleteTimer);
      setMessageText('');
      setDeleteTimer(undefined);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Mock file upload
      const attachment: Message['attachment'] = {
        type: file.type.startsWith('image/') ? 'image' :
              file.type.startsWith('video/') ? 'video' :
              file.type.startsWith('audio/') ? 'audio' : 'file',
        url: URL.createObjectURL(file),
        name: file.name,
      };
      onSendMessage(`Sent ${file.name}`, deleteTimer, attachment);
      setDeleteTimer(undefined);
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getStatusText = (status: Friend['status'], lastSeen?: Date) => {
    if (status === 'online') return 'Active now';
    if (status === 'away') return 'Away';
    if (lastSeen) {
      const diff = Date.now() - lastSeen.getTime();
      if (diff < 3600000) return `Active ${Math.floor(diff / 60000)}m ago`;
      if (diff < 86400000) return `Active ${Math.floor(diff / 3600000)}h ago`;
      return `Active ${Math.floor(diff / 86400000)}d ago`;
    }
    return 'Offline';
  };

  const getStatusColor = (status: Friend['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-400';
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="relative">
            <Avatar className="w-10 h-10">
              <AvatarImage src={friend.avatar} alt={friend.username} />
              <AvatarFallback>{friend.username.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className={`absolute bottom-0 right-0 w-3 h-3 ${getStatusColor(friend.status)} rounded-full border-2 border-white`} />
          </div>
          <div>
            <p>{friend.username}</p>
            <p className="text-xs text-gray-500">
              {getStatusText(friend.status, friend.lastSeen)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {onRemoveFriend && (
                <DropdownMenuItem 
                  onClick={() => setShowRemoveDialog(true)}
                  className="text-red-600 focus:text-red-600"
                >
                  <UserMinus className="w-4 h-4 mr-2" />
                  Remove Friend
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {!conversation || conversation.messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <p>No messages yet</p>
            <p className="text-sm">Start a conversation with {friend.username}</p>
          </div>
        ) : (
          <>
            {conversation.messages.map((message) => (
              <MessageBubble
                key={message.id}
                message={message}
                isOwn={message.senderId === 'me'}
                avatar={message.senderId === 'me' ? undefined : friend.avatar}
                formatTime={formatTime}
              />
            ))}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t bg-white">
        {deleteTimer && (
          <div className="mb-2 px-3 py-2 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-yellow-700">
              <Timer className="w-4 h-4" />
              <span>Message will delete in {deleteTimer}s after sending</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDeleteTimer(undefined)}
              className="h-6 text-xs"
            >
              Cancel
            </Button>
          </div>
        )}
        
        <div className="flex items-end gap-2">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileSelect}
            accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
          />
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="rounded-full flex-shrink-0"
          >
            <Paperclip className="w-5 h-5 text-blue-500" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="rounded-full flex-shrink-0"
          >
            <ImageIcon className="w-5 h-5 text-blue-500" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full flex-shrink-0"
              >
                <Timer className={`w-5 h-5 ${deleteTimer ? 'text-yellow-500' : 'text-blue-500'}`} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => setDeleteTimer(10)}>
                Delete after 10 seconds
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setDeleteTimer(30)}>
                Delete after 30 seconds
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setDeleteTimer(60)}>
                Delete after 1 minute
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setDeleteTimer(300)}>
                Delete after 5 minutes
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setDeleteTimer(undefined)}>
                Don't delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Type a message..."
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              className="rounded-full bg-gray-100 border-0 pr-10"
            />
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1/2 -translate-y-1/2 rounded-full h-8 w-8"
            >
              <Smile className="w-4 h-4 text-gray-400" />
            </Button>
          </div>

          <Button
            onClick={handleSend}
            size="icon"
            disabled={!messageText.trim()}
            className="rounded-full flex-shrink-0 bg-blue-500 hover:bg-blue-600 disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Remove Friend Dialog */}
      {onRemoveFriend && (
        <AlertDialog open={showRemoveDialog} onOpenChange={setShowRemoveDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove Friend</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to remove {friend.username} from your friends list?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  onRemoveFriend(friend.id);
                  setShowRemoveDialog(false);
                }}
              >
                Remove
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
  avatar?: string;
  formatTime: (date: Date) => string;
}

function MessageBubble({ message, isOwn, avatar, formatTime }: MessageBubbleProps) {
  return (
    <div className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
      {!isOwn && avatar && (
        <Avatar className="w-8 h-8 flex-shrink-0">
          <AvatarImage src={avatar} />
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
      )}
      <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'} max-w-[75%]`}>
        {message.attachment && (
          <div className="mb-2">
            {message.attachment.type === 'image' ? (
              <img
                src={message.attachment.url}
                alt={message.attachment.name}
                className="rounded-2xl max-w-full h-auto max-h-64 object-cover"
              />
            ) : (
              <div className={`px-4 py-3 rounded-2xl ${
                isOwn ? 'bg-blue-500 text-white' : 'bg-white border'
              }`}>
                <p className="text-sm">📎 {message.attachment.name}</p>
              </div>
            )}
          </div>
        )}
        
        {message.text && (
          <div
            className={`px-4 py-2 rounded-2xl ${
              isOwn
                ? 'bg-blue-500 text-white rounded-br-sm'
                : 'bg-white border rounded-bl-sm'
            }`}
          >
            <p className="break-words">{message.text}</p>
          </div>
        )}
        
        <div className="flex items-center gap-2 mt-1 px-2">
          <span className="text-xs text-gray-500">
            {formatTime(message.timestamp)}
          </span>
          {message.deleteTimer && (
            <span className="text-xs text-yellow-600 flex items-center gap-1">
              <Timer className="w-3 h-3" />
              {message.deleteTimer}s
            </span>
          )}
          {isOwn && message.status && (
            <span className="text-xs text-gray-500">
              {message.status === 'sent' && '✓'}
              {message.status === 'delivered' && '✓✓'}
              {message.status === 'read' && '✓✓'}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}