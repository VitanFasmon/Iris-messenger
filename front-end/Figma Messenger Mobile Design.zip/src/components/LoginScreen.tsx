import { useState } from 'react';
import { MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface LoginScreenProps {
  isRegister?: boolean;
  onLogin?: (username: string, password: string) => void;
  onRegister?: (username: string, email: string, password: string) => void;
  onSwitchToRegister?: () => void;
  onSwitchToLogin?: () => void;
}

export function LoginScreen({
  isRegister = false,
  onLogin,
  onRegister,
  onSwitchToRegister,
  onSwitchToLogin
}: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isRegister) {
      if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      onRegister?.(username, email, password);
    } else {
      onLogin?.(username, password);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-blue-500 to-purple-600">
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4">
            <MessageCircle className="w-10 h-10 text-blue-500" />
          </div>
          <h1 className="text-white">Messenger</h1>
          <p className="text-blue-100 text-sm mt-2">
            {isRegister ? 'Create your account' : 'Sign in to continue'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username" className="text-white">Username</Label>
            <Input
              id="username"
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="bg-white/90 border-0"
            />
          </div>

          {isRegister && (
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white/90 border-0"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="password" className="text-white">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="bg-white/90 border-0"
            />
          </div>

          {isRegister && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-white">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirm your password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="bg-white/90 border-0"
              />
            </div>
          )}

          <Button type="submit" className="w-full bg-white text-blue-600 hover:bg-blue-50">
            {isRegister ? 'Register' : 'Login'}
          </Button>
        </form>

        {/* Switch */}
        <div className="mt-6 text-center">
          <p className="text-white text-sm">
            {isRegister ? 'Already have an account?' : "Don't have an account?"}
            <button
              onClick={isRegister ? onSwitchToLogin : onSwitchToRegister}
              className="ml-2 underline hover:text-blue-100"
            >
              {isRegister ? 'Login' : 'Register'}
            </button>
          </p>
        </div>

        {/* Terms & Privacy */}
        {isRegister && (
          <div className="mt-4 text-center">
            <p className="text-white text-xs">
              By registering, you agree to our{' '}
              <a href="#" className="underline">Terms of Service</a>
              {' '}and{' '}
              <a href="#" className="underline">Privacy Policy</a>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
