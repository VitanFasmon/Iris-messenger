import { useState } from "react";
import {
  X,
  UserPlus,
  Search,
  Clock,
  Check,
  XCircle,
} from "lucide-react";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "./ui/avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { FriendRequest } from "../App";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";

interface AddFriendModalProps {
  friendRequests: FriendRequest[];
  onClose: () => void;
  onSendRequest: (username: string) => void;
  onAcceptRequest: (requestId: string) => void;
  onDeclineRequest: (requestId: string) => void;
}

export function AddFriendModal({
  friendRequests,
  onClose,
  onSendRequest,
  onAcceptRequest,
  onDeclineRequest,
}: AddFriendModalProps) {
  const [searchUsername, setSearchUsername] = useState("");

  const handleSendRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchUsername.trim()) {
      onSendRequest(searchUsername);
      setSearchUsername("");
    }
  };

  const receivedRequests = friendRequests.filter(
    (r) => r.toUserId === "me" && r.status === "pending",
  );
  const sentRequests = friendRequests.filter(
    (r) => r.fromUserId === "me" && r.status === "pending",
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2>Add Friends</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="rounded-full"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <Tabs
          defaultValue="search"
          className="flex-1 flex flex-col min-h-0"
        >
          <TabsList className="grid w-full grid-cols-3 mx-4 mt-4">
            <TabsTrigger value="search">Search</TabsTrigger>
            <TabsTrigger value="received">
              Received{" "}
              {receivedRequests.length > 0 &&
                `(${receivedRequests.length})`}
            </TabsTrigger>
            <TabsTrigger value="sent">
              Sent{" "}
              {sentRequests.length > 0 &&
                `(${sentRequests.length})`}
            </TabsTrigger>
          </TabsList>

          {/* Search Tab */}
          <TabsContent
            value="search"
            className="flex-1 overflow-y-auto p-4"
          >
            <form
              onSubmit={handleSendRequest}
              className="space-y-4"
            >
              <div className="space-y-2">
                <label className="text-sm">
                  Search by username
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Enter username..."
                    value={searchUsername}
                    onChange={(e) =>
                      setSearchUsername(e.target.value)
                    }
                    className="pl-10"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={!searchUsername.trim()}
                className="w-full bg-blue-500 hover:bg-blue-600"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Send Friend Request
              </Button>
            </form>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-600">
                Enter the exact username of the person you want
                to add as a friend. They will receive a friend
                request that they can accept or decline.
              </p>
            </div>
          </TabsContent>

          {/* Received Requests Tab */}
          <TabsContent
            value="received"
            className="flex-1 overflow-y-auto p-4"
          >
            {receivedRequests.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500 py-8">
                <Clock className="w-12 h-12 mb-4 text-gray-300" />
                <p>No pending requests</p>
                <p className="text-sm">
                  You have no friend requests at the moment
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {receivedRequests.map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50"
                  >
                    <Avatar className="w-12 h-12">
                      <AvatarImage
                        src={request.fromUser.avatar}
                      />
                      <AvatarFallback>
                        {request.fromUser.username.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="truncate">
                        {request.fromUser.username}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(
                          request.timestamp,
                        ).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() =>
                          onAcceptRequest(request.id)
                        }
                        className="bg-green-600 hover:bg-green-700 h-8 w-8 p-0"
                      >
                        <Check className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          onDeclineRequest(request.id)
                        }
                        className="h-8 w-8 p-0 border-red-200 text-red-600 hover:bg-red-50"
                      >
                        <XCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Sent Requests Tab */}
          <TabsContent
            value="sent"
            className="flex-1 overflow-y-auto p-4"
          >
            {sentRequests.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500 py-8">
                <UserPlus className="w-12 h-12 mb-4 text-gray-300" />
                <p>No sent requests</p>
                <p className="text-sm">
                  You haven't sent any friend requests
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {sentRequests.map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center gap-3 p-3 border rounded-lg"
                  >
                    <Avatar className="w-12 h-12">
                      <AvatarImage
                        src={request.fromUser.avatar}
                      />
                      <AvatarFallback>
                        {request.fromUser.username.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="truncate">
                        {request.fromUser.username}
                      </p>
                      <p className="text-xs text-yellow-600 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Pending
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        onDeclineRequest(request.id)
                      }
                      className="h-8"
                    >
                      Cancel
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}