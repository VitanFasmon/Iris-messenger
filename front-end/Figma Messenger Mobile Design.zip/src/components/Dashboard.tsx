import { useState } from 'react';
import { Sidebar } from './Sidebar';
import { FriendsList } from './FriendsList';
import { ChatWindow } from './ChatWindow';
import { SettingsScreen } from './SettingsScreen';
import { AddFriendModal } from './AddFriendModal';
import { User, Friend, Conversation, Message, FriendRequest } from '../App';

interface DashboardProps {
  currentUser: User;
  onLogout: () => void;
}

type DashboardView = 'chats' | 'settings';

export function Dashboard({ currentUser, onLogout }: DashboardProps) {
  const [currentView, setCurrentView] = useState<DashboardView>('chats');
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);

  // Mock data
  const [friends, setFriends] = useState<Friend[]>([
    {
      id: '1',
      username: 'sarah_j',
      email: 'sarah@example.com',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
      status: 'online',
    },
    {
      id: '2',
      username: 'mike_chen',
      email: 'mike@example.com',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
      status: 'online',
    },
    {
      id: '3',
      username: 'emma_wilson',
      email: 'emma@example.com',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
      status: 'away',
    },
    {
      id: '4',
      username: 'james_r',
      email: 'james@example.com',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
      status: 'offline',
      lastSeen: new Date(Date.now() - 3600000),
    },
  ]);

  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: '1',
      friendId: '1',
      unreadCount: 2,
      messages: [
        { id: '1', text: 'Hey! How are you?', senderId: '1', timestamp: new Date(Date.now() - 3600000) },
        { id: '2', text: "I'm doing great! How about you?", senderId: 'me', timestamp: new Date(Date.now() - 3500000) },
        { id: '3', text: 'Pretty good! Want to grab coffee tomorrow?', senderId: '1', timestamp: new Date(Date.now() - 3000000) },
      ]
    },
    {
      id: '2',
      friendId: '2',
      unreadCount: 0,
      messages: [
        { id: '1', text: 'Did you finish the project?', senderId: '2', timestamp: new Date(Date.now() - 7200000) },
        { id: '2', text: 'Almost done!', senderId: 'me', timestamp: new Date(Date.now() - 7000000) },
      ]
    },
  ]);

  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([
    {
      id: '1',
      fromUserId: '5',
      toUserId: 'me',
      fromUser: {
        username: 'alex_smith',
        avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=400&fit=crop',
      },
      status: 'pending',
      timestamp: new Date(Date.now() - 86400000),
    },
  ]);

  const handleSelectFriend = (friend: Friend) => {
    setSelectedFriend(friend);
    setCurrentView('chats');
    
    // Mark messages as read
    setConversations(prev => prev.map(conv => 
      conv.friendId === friend.id ? { ...conv, unreadCount: 0 } : conv
    ));
  };

  const handleBack = () => {
    setSelectedFriend(null);
  };

  const handleSendMessage = (text: string, deleteTimer?: number, attachment?: Message['attachment']) => {
    if (!selectedFriend) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      senderId: 'me',
      timestamp: new Date(),
      status: 'sent',
      deleteTimer,
      attachment,
    };

    setConversations(prev => {
      const convIndex = prev.findIndex(c => c.friendId === selectedFriend.id);
      if (convIndex >= 0) {
        const updated = [...prev];
        updated[convIndex] = {
          ...updated[convIndex],
          messages: [...updated[convIndex].messages, newMessage]
        };
        return updated;
      } else {
        return [...prev, {
          id: Date.now().toString(),
          friendId: selectedFriend.id,
          messages: [newMessage],
          unreadCount: 0,
        }];
      }
    });

    // Auto-delete message if timer is set
    if (deleteTimer) {
      setTimeout(() => {
        setConversations(prev => prev.map(conv => 
          conv.friendId === selectedFriend.id 
            ? {
                ...conv,
                messages: conv.messages.filter(m => m.id !== newMessage.id)
              }
            : conv
        ));
      }, deleteTimer * 1000);
    }
  };

  const handleAcceptRequest = (requestId: string) => {
    const request = friendRequests.find(r => r.id === requestId);
    if (request) {
      const newFriend: Friend = {
        id: request.fromUserId,
        username: request.fromUser.username,
        email: `${request.fromUser.username}@example.com`,
        avatar: request.fromUser.avatar,
        status: 'online',
      };
      setFriends(prev => [...prev, newFriend]);
      setFriendRequests(prev => prev.filter(r => r.id !== requestId));
    }
  };

  const handleDeclineRequest = (requestId: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== requestId));
  };

  const handleSendFriendRequest = (username: string) => {
    // Mock sending request
    console.log('Sending friend request to:', username);
    setShowAddFriendModal(false);
  };

  const handleRemoveFriend = (friendId: string) => {
    setFriends(prev => prev.filter(f => f.id !== friendId));
    setConversations(prev => prev.filter(c => c.friendId !== friendId));
    setSelectedFriend(null);
  };

  const getCurrentConversation = () => {
    if (!selectedFriend) return null;
    return conversations.find(c => c.friendId === selectedFriend.id);
  };

  return (
    <div className="flex flex-col h-full">
      <Sidebar
        currentUser={currentUser}
        currentView={currentView}
        onViewChange={setCurrentView}
        onLogout={onLogout}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        {currentView === 'chats' && !selectedFriend && (
          <FriendsList
            friends={friends}
            conversations={conversations}
            friendRequests={friendRequests}
            onSelectFriend={handleSelectFriend}
            onAddFriend={() => setShowAddFriendModal(true)}
            onAcceptRequest={handleAcceptRequest}
            onDeclineRequest={handleDeclineRequest}
            onRemoveFriend={handleRemoveFriend}
          />
        )}

        {currentView === 'chats' && selectedFriend && (
          <ChatWindow
            friend={selectedFriend}
            conversation={getCurrentConversation()}
            onBack={handleBack}
            onSendMessage={handleSendMessage}
            onRemoveFriend={handleRemoveFriend}
          />
        )}

        {currentView === 'settings' && (
          <SettingsScreen
            currentUser={currentUser}
            onLogout={onLogout}
          />
        )}
      </div>

      {showAddFriendModal && (
        <AddFriendModal
          friendRequests={friendRequests}
          onClose={() => setShowAddFriendModal(false)}
          onSendRequest={handleSendFriendRequest}
          onAcceptRequest={handleAcceptRequest}
          onDeclineRequest={handleDeclineRequest}
        />
      )}
    </div>
  );
}