import { useState } from 'react';
import { Search, UserPlus, Clock } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Friend, Conversation, FriendRequest } from '../App';

interface FriendsListProps {
  friends: Friend[];
  conversations: Conversation[];
  friendRequests: FriendRequest[];
  onSelectFriend: (friend: Friend) => void;
  onAddFriend: () => void;
  onAcceptRequest: (requestId: string) => void;
  onDeclineRequest: (requestId: string) => void;
  onRemoveFriend?: (friendId: string) => void;
}

export function FriendsList({
  friends,
  conversations,
  friendRequests,
  onSelectFriend,
  onAddFriend,
  onAcceptRequest,
  onDeclineRequest,
  onRemoveFriend,
}: FriendsListProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const getLastMessage = (friendId: string) => {
    const conv = conversations.find(c => c.friendId === friendId);
    if (!conv || conv.messages.length === 0) return null;
    return conv.messages[conv.messages.length - 1];
  };

  const getUnreadCount = (friendId: string) => {
    const conv = conversations.find(c => c.friendId === friendId);
    return conv?.unreadCount || 0;
  };

  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return `${Math.floor(diff / 86400000)}d ago`;
  };

  const filteredFriends = friends.filter(friend =>
    friend.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: Friend['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-400';
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <h2>Messages</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onAddFriend}
            className="rounded-full"
          >
            <UserPlus className="w-5 h-5" />
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search friends..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-gray-100 border-0 rounded-full"
          />
        </div>
      </div>

      {/* Friend Requests */}
      {friendRequests.length > 0 && (
        <div className="border-b bg-blue-50 p-4">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-4 h-4 text-blue-600" />
            <span className="text-sm text-blue-600">Pending Requests ({friendRequests.length})</span>
          </div>
          <div className="space-y-2">
            {friendRequests.map(request => (
              <div key={request.id} className="flex items-center gap-3 bg-white p-3 rounded-lg">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={request.fromUser.avatar} />
                  <AvatarFallback>{request.fromUser.username.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="truncate">{request.fromUser.username}</p>
                  <p className="text-xs text-gray-500">Friend request</p>
                </div>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    onClick={() => onAcceptRequest(request.id)}
                    className="bg-blue-600 hover:bg-blue-700 h-8 px-3"
                  >
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onDeclineRequest(request.id)}
                    className="h-8 px-3"
                  >
                    Decline
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Friends List */}
      <div className="flex-1 overflow-y-auto">
        {filteredFriends.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 p-8">
            <UserPlus className="w-12 h-12 mb-4 text-gray-300" />
            <p>No friends yet</p>
            <p className="text-sm">Add friends to start chatting</p>
          </div>
        ) : (
          filteredFriends.map(friend => {
            const lastMessage = getLastMessage(friend.id);
            const unreadCount = getUnreadCount(friend.id);

            return (
              <button
                key={friend.id}
                onClick={() => onSelectFriend(friend)}
                className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 transition-colors border-b"
              >
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={friend.avatar} alt={friend.username} />
                    <AvatarFallback>{friend.username.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 ${getStatusColor(friend.status)} rounded-full border-2 border-white`} />
                </div>

                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center justify-between mb-1">
                    <span className="truncate">{friend.username}</span>
                    {lastMessage && (
                      <span className="text-xs text-gray-500 ml-2">
                        {formatTimestamp(lastMessage.timestamp)}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-500 truncate">
                      {lastMessage ? lastMessage.text : 'No messages yet'}
                    </p>
                    {unreadCount > 0 && (
                      <Badge className="ml-2 bg-blue-500 hover:bg-blue-600 min-w-[20px] h-5 flex items-center justify-center px-1.5">
                        {unreadCount}
                      </Badge>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}