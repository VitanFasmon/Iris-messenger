import { MessageCircle, Settings, LogOut } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Button } from './ui/button';
import { User } from '../App';

interface SidebarProps {
  currentUser: User;
  currentView: 'chats' | 'settings';
  onViewChange: (view: 'chats' | 'settings') => void;
  onLogout: () => void;
}

export function Sidebar({ currentUser, currentView, onViewChange, onLogout }: SidebarProps) {
  return (
    <div className="h-16 bg-gray-900 flex items-center justify-between px-4">
      {/* User Profile & App Name */}
      <div className="flex items-center gap-3">
        <Avatar className="w-10 h-10 cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all">
          <AvatarImage src={currentUser.avatar} alt={currentUser.username} />
          <AvatarFallback>{currentUser.username.charAt(0).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="text-white">
          <p className="text-sm">{currentUser.username}</p>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onViewChange('chats')}
          className={`rounded-xl ${
            currentView === 'chats'
              ? 'bg-blue-600 text-white hover:bg-blue-700'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => onViewChange('settings')}
          className={`rounded-xl ${
            currentView === 'settings'
              ? 'bg-blue-600 text-white hover:bg-blue-700'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <Settings className="w-5 h-5" />
        </Button>

        <div className="w-px h-6 bg-gray-700 mx-2" />

        {/* Logout */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onLogout}
          className="text-gray-400 hover:text-white hover:bg-red-600 rounded-xl"
        >
          <LogOut className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}