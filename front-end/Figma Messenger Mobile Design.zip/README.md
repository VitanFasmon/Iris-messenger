
  # Messenger Mobile Design

  This is a code bundle for Messenger Mobile Design. The original project is available at https://www.figma.com/design/FtxayR92SDttlH3C02u9hk/Messenger-Mobile-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  